@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Create the virtual environment first - see the README, section "Run without Docker".
  exit /b 1
)
call .venv\Scripts\activate
rem Use --host 0.0.0.0 instead of 127.0.0.1 to let other computers on your network open it (the login still applies).
python -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000
