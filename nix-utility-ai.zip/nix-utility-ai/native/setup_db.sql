-- Run once as the PostgreSQL administrator:  psql -U postgres -f native/setup_db.sql
-- Creates the app's database user and database, and turns on PostGIS. Change the password here and in DATABASE_URL if you like.
CREATE USER nix WITH PASSWORD 'nix';
CREATE DATABASE nix OWNER nix;
\c nix
CREATE EXTENSION IF NOT EXISTS postgis;
