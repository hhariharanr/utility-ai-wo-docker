"""Where things live. Works the same in Docker (code in /app, data in /data) and when run directly from the project folder."""
import configparser, os
BASE = os.path.dirname(os.path.abspath(__file__))                       # the backend folder
PARENT = os.path.dirname(BASE)
ROOT = PARENT if os.path.isdir(os.path.join(PARENT, "frontend")) else BASE   # project folder, or /app inside the container
DATA = os.getenv("DATA_DIR") or ("/data" if os.path.exists("/.dockerenv") else os.path.join(ROOT, "data"))
FRONT = os.path.join(ROOT, "frontend")

def find(name):  # a config file kept in the project folder (or next to the code)
    return next((p for p in (os.path.join(ROOT, name), os.path.join(BASE, name)) if os.path.exists(p)), os.path.join(ROOT, name))

def database_url():  # DATABASE_URL env var wins (Docker); else [db] url in db.ini; else a local PostgreSQL
    if os.getenv("DATABASE_URL"): return os.environ["DATABASE_URL"]
    cp = configparser.ConfigParser(interpolation=None); cp.read(find("db.ini"))
    u = cp["db"].get("url", "").strip() if cp.has_section("db") else ""
    return u or "postgresql://nix:nix@localhost:5432/nix"
